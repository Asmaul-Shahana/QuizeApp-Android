package com.example.visitingcard;

public class ConvertCurrency {

    public static double usdBDT(double usdB){
        usdB=usdB*107;
        return usdB;
    }
    public static double bdtU(double bdtU){
        bdtU=bdtU/107;
        return bdtU;
    }
    public static double inrU(double inrU){
        inrU=inrU*107;
        return inrU;
    }
}